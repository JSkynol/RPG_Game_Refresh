package main.quest.interfaces;


public class QuestFindTresure extends Quests {

	public QuestFindTresure(String name, Quests qprev, Quests qnext, String desc, boolean timed, int time) {
		super(name, qprev, qnext, desc, timed, time);
		// TODO Auto-generated constructor stub
	}

}

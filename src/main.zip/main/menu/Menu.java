package main.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import main.game.GamePanel;

public class Menu extends JPanel {
	private static final long serialVersionUID = 1L;
	private JFrame f;
	JPanel p;
	JButton btn_startGame, btn_Options  ;
	
	public Menu(JFrame frame) {
		p = this;
		f = frame;
		createMainMenu();
	}

	private void createMainMenu() {
		btn_startGame = new JButton("Start Game");
		btn_startGame.setActionCommand("click_startGame");
		btn_startGame.addActionListener(al);
		btn_Options = new JButton("Options Menu");
		btn_Options.setActionCommand("click_optionsMenu");
		btn_Options.addActionListener(al);
		p.add(btn_startGame);
	}

	ActionListener al = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent event) {
			if (event.getActionCommand().equals("click_startGame")) {
				f.remove(p);
				f.add(new GamePanel(f));
				f.revalidate();
				f.repaint();

			}
			if (event.getActionCommand().equals("click_optionsMenu")) {
				//add Options Menu to frame
			}
		}
	};
}

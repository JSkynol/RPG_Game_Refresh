package main.game;

import java.awt.KeyEventDispatcher;
import java.awt.event.KeyEvent;

public class KeyManager implements KeyEventDispatcher {
	public boolean up, down, left, right;

	@Override
	public boolean dispatchKeyEvent(KeyEvent e) {
		String x = String.valueOf(e.getKeyChar());
		if (x.equals("w")) {
			up = true;
		} else if (x.equals("s")) {
			down = true;
		} else if (x.equals("a")) {
			left = true;
		} else if (x.equals("d")) {
			right = true;
		} else {
			up = false;
			down = false;
			left = false;
			right = false;
		}

		return false;
	}

}

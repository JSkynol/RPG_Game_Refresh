package main.game;

import java.awt.Color;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel  {
	private static final long serialVersionUID = 2L;
	JFrame f;JPanel p;
KeyManager km;
	Timer timer;
	int fpsLimit = 120, currentFrame = 0;

	int leftMove[] = { 37, 65, 100 }, upMove[] = { 38, 86, 104 }, rightMove[] = { 39, 68, 102 }, downMove[] = { 40, 83, 98 };
	

	public GamePanel(JFrame frame) {
		f = frame;
		p = this;
//		p.addKeyListener(this);
		 km = new KeyManager();
		 KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
		 manager.addKeyEventDispatcher(km);
		p.setBackground(Color.red);
		p.repaint();
		
		
		
		
		createTimer();
	}

	//private void setupLevelAndRendering() {
		// TODO menu?
		// TODO drawLevel
		// TODO drawEntities
		// TODO drawPlayer
	//}

	public void createTimer() {
		timer = new Timer(0, null);
		timer.setDelay(1000 / (fpsLimit * 2));
		timer.setRepeats(true);
		timer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				gametick();
			}
		});
		timer.start();
	}

	public void gametick() {
		if(km.up){/*movePlayerUp*/}
		if(km.down){/*movePlayerDown*/}
		if(km.left){/*movePlayerLeft*/}
		if(km.right){/*movePlayerRight*/}
		
		// TODO Entity Updates
		// TODO player update
	}

}

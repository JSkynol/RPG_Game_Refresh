package main.game;

public class GamePause {

}

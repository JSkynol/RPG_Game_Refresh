package main;

import java.awt.Color;
import javax.swing.JFrame;
import main.menu.Menu;

public class InitialStart{
	public static void main(String[] args) {
		InitialStart init = new InitialStart();
		init.setupFrame();
	}

	private JFrame frame;
	private Menu menu;
	private String gameTitle = "Game Title";

	public InitialStart() { 
		frame = new JFrame(gameTitle);
		frame.setSize(1000, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setBackground(Color.orange);
		
	}

	private void setupFrame() {
		menu = new Menu(frame);
			frame.add(menu);
		
	}
	
}
package main.entities;

public class Player extends Entity{

}

package main.entities;

import java.awt.Image;

public class Entity {
	private String name;
	private Image[] image;
	public Entity() {
	}

	public Entity(String a) {
		this.name = a;
	}
	public Entity(String a, Image[] b){
		this.name  = a;
		this.image = b;
	}

	public void setName(String a) {
		this.name = a;
	}
	public void setImageArray(Image[] b){
		this.image = b;
	}
}

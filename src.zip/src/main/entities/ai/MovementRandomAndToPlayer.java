package main.entities.ai;

import main.entities.Entity;

public class MovementRandomAndToPlayer implements AIBase{
private Entity ent;
	public MovementRandomAndToPlayer(Entity e) {
		ent = e;
	}


	@Override
	public int moveDirection() {
		// TODO Auto-generated method stub
		return 0;
	}


}

package main.game.levels;


public class DefaultLevel {
	public DefaultLevel(){
		
	}
	
	
}

package main.entities.ai;


public interface AIBase {
	
	int moveDirection();
}

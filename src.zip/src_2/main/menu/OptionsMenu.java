package main.menu;

import javax.swing.JPanel;

public class OptionsMenu extends JPanel{
	private static final long serialVersionUID = 3L;

}

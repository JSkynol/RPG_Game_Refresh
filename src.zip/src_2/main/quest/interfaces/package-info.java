/**
 * 
 */
/**
 * @author Callum
 *
 */
package main.quest.interfaces;